<#
.SYNOPSIS
  Copie "Mon patrimoine" vers ton depot git de deploiement, apres verification. Ne fait JAMAIS de git push.

.DESCRIPTION
  1. Verifie la coherence du dossier de travail (version <-> cache du service worker, liste SHELL de sw.js,
     scripts du HTML, ordre de chargement). Une erreur = rien n'est copie.
  2. Compare avec le depot (fichiers ajoutes / modifies / supprimes / identiques) et demande confirmation.
  3. Copie les fichiers de l'application ; js/ est recopie en MIROIR (un fichier supprime ou renomme ici
     disparait aussi du depot, sinon il resterait en double).
  Les fichiers de travail (.claude/, tests/, package.json...) ne sont PAS copies, sauf avec -WithTests.

.PARAMETER Dest       Dossier du depot git de deploiement. Memorise dans .claude/deploy.config.json apres la 1re utilisation.
.PARAMETER CheckOnly  Verifie seulement le dossier de travail, ne regarde pas le depot, ne copie rien.
.PARAMETER DryRun     Montre ce qui serait copie / supprime, ne copie rien.
.PARAMETER WithTests  Copie aussi tests/, utils.test.js, tests.html, package.json et vitest.config.js (pour lancer npm test dans le depot).
.PARAMETER Yes        Ne demande pas de confirmation.
.PARAMETER Force      Autorise a copier une version plus ANCIENNE que celle du depot.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .claude\deploy.ps1 -Dest "C:\chemin\vers\mon-depot"
  powershell -ExecutionPolicy Bypass -File .claude\deploy.ps1 -DryRun
#>
param(
  [string]$Dest,
  [switch]$CheckOnly,
  [switch]$DryRun,
  [switch]$WithTests,
  [switch]$Yes,
  [switch]$Force
)
$ErrorActionPreference = 'Stop'

$Src        = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..')).TrimEnd('\')
$ConfigFile = Join-Path $PSScriptRoot 'deploy.config.json'

function Fail($msg) { Write-Host ("X " + $msg) -ForegroundColor Red; exit 1 }
function Ok($msg)   { Write-Host ("OK " + $msg) -ForegroundColor Green }
function Warn($msg) { Write-Host ("!  " + $msg) -ForegroundColor Yellow }
function ReadText($p) { [System.IO.File]::ReadAllText($p, [System.Text.Encoding]::UTF8) }
function Rel($full, $root) { $full.Substring($root.Length + 1).Replace('\', '/') }

# ---------------------------------------------------------------- 1. Verification du dossier de travail
Write-Host ""
Write-Host "== Verification du dossier de travail ==" -ForegroundColor Cyan
Write-Host "   $Src"

foreach ($f in @('mon-patrimoine.js', 'sw.js', 'mon-patrimoine.html')) {
  if (-not (Test-Path (Join-Path $Src $f))) { Fail "Fichier introuvable : $f (le script doit rester dans .claude\ du dossier de l'application)" }
}
$main = ReadText (Join-Path $Src 'mon-patrimoine.js')
$sw   = ReadText (Join-Path $Src 'sw.js')
$html = ReadText (Join-Path $Src 'mon-patrimoine.html')

$errors = New-Object System.Collections.ArrayList
function Check($cond, $msg) { if (-not $cond) { [void]$errors.Add($msg) } }

$mv = [regex]::Match($main, "const APP_VERSION = '(\d+)\.(\d+)\.(\d+)'")
$cv = [regex]::Match($sw, "const CACHE = 'patrimoine-v(\d+)'")
Check $mv.Success "APP_VERSION introuvable dans mon-patrimoine.js"
Check $cv.Success "CACHE introuvable dans sw.js"
$version = ''
if ($mv.Success -and $cv.Success) {
  $version = $mv.Groups[1].Value + '.' + $mv.Groups[2].Value + '.' + $mv.Groups[3].Value
  Check ($mv.Groups[3].Value -eq $cv.Groups[1].Value) ("Version et cache desalignes : APP_VERSION = $version mais sw.js = patrimoine-v" + $cv.Groups[1].Value + " (le 3e chiffre doit etre le numero du cache)")
}

$shellBlock = [regex]::Match($sw, "const SHELL = \[([\s\S]*?)\]")
Check $shellBlock.Success "Liste SHELL introuvable dans sw.js"
$shell = @(); if ($shellBlock.Success) { $shell = @([regex]::Matches($shellBlock.Groups[1].Value, "'\./([^']+)'") | ForEach-Object { $_.Groups[1].Value }) }
$scripts = @([regex]::Matches($html, '<script src="([^"]+)"></script>') | ForEach-Object { $_.Groups[1].Value })

foreach ($s in $shell)   { Check (Test-Path (Join-Path $Src $s)) "SHELL (sw.js) : fichier inexistant -> $s  (cache.addAll echouerait : le service worker ne s'installerait pas)" }
foreach ($s in $scripts) { Check (Test-Path (Join-Path $Src $s)) "HTML : <script src=""$s""> pointe vers un fichier inexistant"
                           Check ($shell -contains $s)           "HTML : $s est charge mais absent de SHELL (hors-ligne, l'app serait cassee)" }
foreach ($s in ($shell | Where-Object { $_ -like 'tests/*' -or $_ -eq 'package.json' })) { Check $false "SHELL ne doit pas contenir $s" }

$jsFiles = @()
if (Test-Path (Join-Path $Src 'js')) {
  $jsFiles = @(Get-ChildItem (Join-Path $Src 'js') -Recurse -Filter *.js -File | ForEach-Object { Rel $_.FullName $Src })
}
foreach ($j in $jsFiles) {
  Check ($scripts -contains $j) "$j existe mais n'est pas charge par le HTML"
  Check ($shell   -contains $j) "$j existe mais est absent de SHELL"
}
if ($scripts.Count -gt 0) { Check ($scripts[$scripts.Count - 1] -eq 'mon-patrimoine.js') "mon-patrimoine.js doit etre le DERNIER script du HTML" }
$iu = [array]::IndexOf($scripts, 'utils.js'); $ig = [array]::IndexOf($scripts, 'js/core/dom-guard.js')
Check ($iu -ge 0 -and $ig -eq $iu + 1) "js/core/dom-guard.js doit suivre immediatement utils.js (il cree les elements que les scripts suivants ciblent)"

if ($errors.Count -gt 0) {
  foreach ($e in $errors) { Write-Host ("X " + $e) -ForegroundColor Red }
  Fail ("$($errors.Count) probleme(s) : rien n'a ete copie.")
}
Ok "Version $version = cache patrimoine-v$($cv.Groups[1].Value)"
Ok "$($scripts.Count) scripts dans le HTML, $($shell.Count) fichiers dans SHELL, tous presents et coherents"
if ($CheckOnly) { Write-Host ""; Write-Host "Verification seule : aucune copie." -ForegroundColor Cyan; exit 0 }

# ---------------------------------------------------------------- 2. Destination
if (-not $Dest -and (Test-Path $ConfigFile)) {
  try { $Dest = (Get-Content $ConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json).dest } catch { }
  if ($Dest) { Write-Host "   Depot memorise : $Dest" }
}
if (-not $Dest) {
  $Dest = Read-Host "Chemin du depot git de deploiement (celui sur lequel tu fais git push)"
}
$Dest = $Dest.Trim().Trim('"')
if (-not (Test-Path $Dest -PathType Container)) { Fail "Dossier introuvable : $Dest" }
$Dest = [System.IO.Path]::GetFullPath($Dest).TrimEnd('\')

if ($Dest -ieq $Src) {
  Fail ("La destination est le dossier de travail lui-meme : $Dest`n   Ce dossier n'est pas ton depot git ; donne le dossier du depot sur lequel tu fais git push.")
}
if ($Dest.StartsWith($Src + '\', [System.StringComparison]::OrdinalIgnoreCase)) { Fail "La destination ne peut pas etre a l'interieur du dossier de travail." }
if ($Src.StartsWith($Dest + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
  Warn "Le dossier de travail est DANS la destination : verifie que c'est bien le bon depot."
}
if (-not (Test-Path (Join-Path $Dest '.git'))) {
  Warn "Pas de dossier .git dans la destination : ce n'est peut-etre pas un depot git."
  if (-not $Yes) { if ((Read-Host "Continuer quand meme ? (o/N)") -notmatch '^[oOyY]') { Fail "Abandon." } }
}

# Garde-fou : ne jamais ecraser une version plus recente par une plus ancienne
$destMain = Join-Path $Dest 'mon-patrimoine.js'
$destVersion = ''
if (Test-Path $destMain) {
  $dm = [regex]::Match((ReadText $destMain), "const APP_VERSION = '(\d+)\.(\d+)\.(\d+)'")
  if ($dm.Success) {
    $destVersion = $dm.Groups[1].Value + '.' + $dm.Groups[2].Value + '.' + $dm.Groups[3].Value
    if ([int]$dm.Groups[3].Value -gt [int]$mv.Groups[3].Value -and -not $Force) {
      Fail "Le depot est en version $destVersion, plus RECENTE que le dossier de travail ($version). Rien copie. (-Force pour passer outre)"
    }
  }
}

# ---------------------------------------------------------------- 3. Plan de copie
$files = New-Object System.Collections.ArrayList
foreach ($f in @('index.html', 'mon-patrimoine.html', 'mon-patrimoine.css', 'mon-patrimoine.js', 'utils.js', 'sw.js', 'manifest.json', 'icon.svg')) { [void]$files.Add($f) }
foreach ($j in $jsFiles) { [void]$files.Add($j) }
$mirrorDirs = @('js')
if (Test-Path (Join-Path $Dest 'proxy-worker.js')) { [void]$files.Add('proxy-worker.js') }   # seulement si le depot le versionne deja
if ($WithTests) {
  foreach ($f in @('package.json', 'vitest.config.js', 'utils.test.js', 'tests.html')) { if (Test-Path (Join-Path $Src $f)) { [void]$files.Add($f) } }
  if (Test-Path (Join-Path $Src 'tests')) {
    Get-ChildItem (Join-Path $Src 'tests') -Recurse -File | ForEach-Object { [void]$files.Add((Rel $_.FullName $Src)) }
    $mirrorDirs += 'tests'
  }
}
foreach ($f in $files) { if (-not (Test-Path (Join-Path $Src $f))) { Fail "Fichier a copier introuvable : $f" } }

# Comparaison du CONTENU : git sous Windows (core.autocrlf=true) extrait les fichiers en CRLF alors que le dossier
# de travail est en LF. Un fichier qui ne differe que par ses fins de ligne est donc considere comme identique
# (sinon tout apparaitrait " modifie "). Les fichiers binaires sont compares octet par octet (hash).
function SameContent($a, $b) {
  $ba = [System.IO.File]::ReadAllBytes($a); $bb = [System.IO.File]::ReadAllBytes($b)
  if (([System.Array]::IndexOf($ba, [byte]0) -ge 0) -or ([System.Array]::IndexOf($bb, [byte]0) -ge 0)) {
    return ((Get-FileHash $a -Algorithm SHA256).Hash -eq (Get-FileHash $b -Algorithm SHA256).Hash)
  }
  $ta = [System.Text.Encoding]::UTF8.GetString($ba).Replace("`r`n", "`n")
  $tb = [System.Text.Encoding]::UTF8.GetString($bb).Replace("`r`n", "`n")
  return ($ta -ceq $tb)
}

$added = @(); $changed = @(); $same = 0
foreach ($f in $files) {
  $d = Join-Path $Dest $f
  if (-not (Test-Path $d)) { $added += $f }
  elseif (-not (SameContent (Join-Path $Src $f) $d)) { $changed += $f }
  else { $same++ }
}
$deleted = @()
foreach ($m in $mirrorDirs) {
  $md = Join-Path $Dest $m
  if (Test-Path $md) {
    foreach ($x in (Get-ChildItem $md -Recurse -File)) { $r = Rel $x.FullName $Dest; if ($files -notcontains $r) { $deleted += $r } }
  }
}

Write-Host ""
Write-Host "== Plan de copie vers $Dest ==" -ForegroundColor Cyan
if ($destVersion) { Write-Host "   Version du depot : $destVersion  ->  $version" } else { Write-Host "   Version : $version (depot vide ou sans mon-patrimoine.js)" }
foreach ($f in $added)   { Write-Host ("   + ajoute   " + $f) -ForegroundColor Green }
foreach ($f in $changed) { Write-Host ("   ~ modifie  " + $f) -ForegroundColor Yellow }
foreach ($f in $deleted) { Write-Host ("   - supprime " + $f) -ForegroundColor Red }
Write-Host ("   = " + $same + " fichier(s) identique(s)")
Write-Host ("   Total : " + $added.Count + " ajoute(s), " + $changed.Count + " modifie(s), " + $deleted.Count + " supprime(s)")

if (($added.Count + $changed.Count + $deleted.Count) -eq 0) { Write-Host ""; Ok "Le depot est deja a jour : rien a copier."; exit 0 }
if ($DryRun) { Write-Host ""; Write-Host "Simulation (-DryRun) : rien n'a ete copie." -ForegroundColor Cyan; exit 0 }

if (-not $Yes) { if ((Read-Host "Copier ? (o/N)") -notmatch '^[oOyY]') { Fail "Abandon, rien n'a ete copie." } }

# ---------------------------------------------------------------- 4. Copie
foreach ($f in ($added + $changed)) {
  $d = Join-Path $Dest $f
  $dir = Split-Path $d -Parent
  if (-not (Test-Path $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
  Copy-Item (Join-Path $Src $f) $d -Force
}
foreach ($f in $deleted) { Remove-Item (Join-Path $Dest $f) -Force }
foreach ($m in $mirrorDirs) {   # dossiers devenus vides
  $md = Join-Path $Dest $m
  if (Test-Path $md) { Get-ChildItem $md -Recurse -Directory | Sort-Object { $_.FullName.Length } -Descending | Where-Object { -not (Get-ChildItem $_.FullName -Force) } | Remove-Item -Force }
}
try { (@{ dest = $Dest } | ConvertTo-Json) | Set-Content $ConfigFile -Encoding UTF8 } catch { }

Write-Host ""
Ok "Copie terminee : version $version dans $Dest"
Write-Host ""
Write-Host "Prochaines etapes (a faire toi-meme) :" -ForegroundColor Cyan
Write-Host "  1. Reglages > Exporter les donnees (JSON) sur le telephone, par precaution."
Write-Host "  2. Dans le depot : git add -A ; git commit -m ""v$version"" ; git push"
Write-Host "  3. Attendre le workflow GitHub Pages, puis ouvrir l'appli (au besoin : Reglages > Rechercher une mise a jour)."
