# Commentaires de revue : PR #1 (alexandrebourgoin/Patrimoine)

Chaque bloc est un commentaire à coller sur le fichier indiqué. Le premier est le commentaire général.

---

## Commentaire général (à poster sur la PR)

Merci pour le travail, il y a de bonnes idées (modèle de liquidités par devise, contrôle des ventes, écrans d'analyse). En l'état, je ne peux pas merger : la PR est trop large et plusieurs changements empilent des surcharges de fonctions au lieu de modifier les fichiers sources.

**À corriger avant tout :**
1. Retirer `.github/workflows/prepare-v129.yml`.
2. Restaurer l'espace fine insécable dans `utils.js` (`fmtPct`).
3. Découper la PR par fonctionnalité.
4. Supprimer les redéfinitions de fonctions entre `js/screens/account.js` et `mon-patrimoine.js`.

Détail par fichier ci-dessous.

**Périmètre.** La branche s'appelle `feat/mouvement-depuis-position`, mais elle contient une quarantaine de commits (versions 1.11.113 à 1.11.130) : DCA, ordres limites, alertes, immobilier, performance multi-devises, règles de comptes, « Non synchro », refonte de l'accueil et de l'Analyse. Impossible à relire ou à annuler proprement. Proposition de découpage :
- Mouvement depuis la fiche titre + contrôle des ventes
- Ordres limites et alertes
- Liquidités par devise, régularisation, performance
- DCA (ISIN, montants/%, projection)
- Immobilier
- Accueil et Analyse
- Règles compte/type d'actif et devise par type de compte

---

## `.github/workflows/prepare-v129.yml` (bloquant)

Ce workflow est un artefact de fork : il est gardé par `github.repository == 'julienluigi/Patrimoine'`, demande `contents: write` et pousse un commit de bump vers `feat/mouvement-depuis-position`. Il ne tourne jamais sur ce repo et n'a rien à faire dans la PR. Son nom dit v129 alors qu'il applique la 130. À supprimer. Le bump de version se fait à la main (`APP_VERSION` + `CACHE`).

---

## `utils.js`, ligne `fmtPct` (bloquant)

Dans `fmtPct`, l'espace fine insécable (U+202F, octets `e2 80 af`) avant `%` est devenue une espace normale (`' %'`). Le commentaire juste au-dessus a le même problème. C'est probablement un effet de l'éditeur. Conséquence : retour à la ligne possible entre le chiffre et `%`. À restaurer (`' %'` si tu veux rendre l'intention explicite).

Même remarque pour les lignes de séparateurs de commentaires modifiées sans raison : elles ajoutent du bruit au diff.

---

## `js/core/screens.js` (important)

Dans un `DOMContentLoaded`, ce fichier réassigne `renderImmo`, `immoCalc`, `_imRead`, `openImmoForm`, `bindImmo`, `saveImmo` et même `renderScreen`. Il retrouve aussi la ligne « Frais de notaire » en relisant le HTML déjà rendu (`drawDetail`), et injecte un `<style>` avec `!important`.

Problèmes :
- Ça ne marche que si ces symboles restent des `let` ou `function` globales. Un renommage ou un `const` casse sans erreur claire.
- `bindImmo` pose un listener `{once:true}` ET un `el.onclick` qui font la même chose.
- `saveImmo` est surchargé ici, dans `dashboard.js` et défini dans `mon-patrimoine.js` : trois niveaux dont l'ordre n'est pas lisible.
- `immodetail` n'est pas dans les `fallbacks` de `back()`.

Ces changements (résidence secondaire, autres frais, fiche détail) doivent être faits dans le module immobilier lui-même, pas par-dessus.

---

## `js/screens/account.js` et `mon-patrimoine.js` (majeur)

`mon-patrimoine.js` est chargé après `js/screens/account.js` (`mon-patrimoine.html:758`). Il redéfinit `accPerfInfo`, `accValueOnDay`, `accPerfPeriod`, `accPerfSummary` et `loadBenchmark` avec des versions différentes. Ce sont celles de `mon-patrimoine.js` qui s'exécutent : environ 150 lignes d'`account.js` sont donc du code mort, et toute correction faite dans `account.js` est sans effet.

`mon-patrimoine.js` surcharge aussi `getAccountMoves`, `renderAccount` et `renderScreen`. Pour `renderAccount`, il utilise une regex sur le HTML rendu et un `indexOf` sur une chaîne de style exacte pour insérer un bloc. Si ce style change dans `account.js`, le bloc disparaît sans erreur (`i < 0 ? html`).

À faire : une seule définition par fonction, dans le fichier du module (`js/screens/account.js`), et plus aucune surcharge dans `mon-patrimoine.js`.

---

## `js/screens/account.js`, `accPerfInfo` (à vérifier)

Cette version somme `c.amount` et convertit avec la devise du compte, sans lire `c.ccy` alors que la PR introduit une devise par apport (`cashflow.js`, `utils.js`). Vérifie que la version de `mon-patrimoine.js` (via `_accFlows`) gère bien `ccy`. Il y a aujourd'hui trois calculs de performance (`accPerfInfo`/`accPerfPeriod`, `accFlowSim` dans `utils.js`, `accPerfPct`) : à unifier ou au moins tester ensemble sur un cas multi-devises.

---

## `js/screens/dashboard.js` (important)

- `installWealthPresentation()` encapsule `renderAnalysis` et remplace « Patrimoine total » par « Comptes financiers ». Or `analysisData().tot` inclut déjà la valeur nette immobilière : la carte « Comptes financiers » contient donc de l'immobilier.
- L'autre `.replace("comment il est placé aujourd'hui", …)` ne correspond à rien : le texte réel est « comment le patrimoine est placé aujourd'hui ».
- `wealthBreakdown()` écarte les biens dont la date d'achat est dans le futur ou dont les valeurs ne sont pas finies. `analysisData()` ne le fait pas. Les deux totaux peuvent diverger.
- `saveImmo` est surchargé ici pour appeler `refreshMain()` : chaque sauvegarde réaffiche tous les écrans.
- Fonctionnalités supprimées sans mention : variation du jour (▲/▼ %), P&L avec pourcentage, pastille de fraîcheur des cours, toast de retrait d'un favori, delta en devise des titres suivis. Le bouton « Trier » n'indique plus le mode actif.
- Le fichier est réécrit en lignes très denses, difficiles à relire.

Même remarque pour la suppression du `stat-row` (dont « Variation J ») sur l'écran de compte.

---

## `js/core/navigation.js` et `js/core/shell.js` (mineur)

- `.replace('>Ordres en cours<','>Ordres<')` ne correspond plus à rien : `renderOrders` affiche « Ordres et alertes ». Le titre de l'écran et le libellé du menu divergent.
- `navBadgeCount` est défini dans `shell.js` (ordres seulement) et dans `mon-patrimoine.js` (ordres + alertes). C'est la dernière qui s'applique, la première est du code mort et trompeur. En garder une seule.

---

## `js/services/prices.js`, « Non synchro » (important)

`priceAt` n'existe pas dans les données existantes. Après la mise à jour, toutes les positions sont « jamais synchronisées » et le badge est rouge jusqu'au premier refresh. Les positions à prix manuel (sans source en ligne) restent signalées en permanence. À traiter : initialiser `priceAt` à la migration, ou ignorer les positions sans source. Vérifier aussi que `priceAt` est conservé à la sauvegarde.

---

## `js/features/dca.js` (important)

- Bascule % ↔ € : si le budget est vide, `readDcaPlanForm` met tous les poids à 0, donc la saisie est perdue en basculant.
- `_dcaAmt` arrondit au centime : 3 × 33,33 € sur 100 € donne 99,99 %, et la validation `> 0.01` est alors à la limite. Elle peut refuser un plan valide.
- `dcaResolveIsins` remplace `l.ticker` par le ticker résolu sans vérifier qu'il n'existe pas déjà dans le plan.

---

## `js/modals/order.js`, stockage (important)

Ordres, alertes et immobilier utilisent des clés `localStorage` simples (`patrimoine-orders`, `patrimoine-alerts`, `patrimoine-immo`), alors que le DCA a des emplacements séparés démo/réel. Vérifier : (1) séparation démo/réel, (2) inclusion dans l'export/import de sauvegarde.

---

## `js/modals/account.js` et `js/modals/position.js` (mineur)

- `ACC_TYPE_CCY` et `allowedAssetTypes` reposent sur des libellés exacts et des regex. Une faute de frappe dans `ACCOUNT_TYPES` désactive la règle sans rien dire. Ajouter un test ou une vérification au démarrage.
- Les ETF ne sont pas contrôlés pour l'éligibilité au PEA, seulement les actions.
- Les anciens apports sans `ccy` reprennent la devise courante du compte : changer la devise du compte les réinterprète. Prévoir une migration qui écrit `ccy` une fois.

---

## Points positifs (à mentionner)

- Le contrôle « on ne peut pas vendre plus que détenu » rejoue l'historique et gère les ventes le même jour.
- Le modèle de liquidités par devise et le traitement des régularisations comme des flux (jamais comme des gains) sont cohérents.
- L'échappement `esc()` est systématique dans les nouveaux templates.
